package com.etag.onlinelogger

data class LogResponse(
    val statusCode: Int,
    val message: String
)