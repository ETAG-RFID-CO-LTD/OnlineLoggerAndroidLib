package com.etag.onlinelogger

data class LogRequest(
    val projectName: String,
    val msg: String
)